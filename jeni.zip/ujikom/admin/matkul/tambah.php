<!DOCTYPE html>
<html>
<head>
<title>Tambah Data Mata Kuliah</title>
</head>
<body>
<h2>Tambah Data Mata Kuliah</h2>
<br/>
<a href="index.php">KEMBALI</a>
<br/>
<form method="post" action="tambah_aksi.php">
<table>
<tr>
<td>Kode</td>
<td><input type="number" name="kd_matkul"></td>
</tr>
<tr>
<td>Nama Mata Kuliah</td>
<td><input type="text" name="nama"></td>
</tr>
<tr>
<td>SKS</td>
<td><input type="text" name="sks"></td>
</tr>
<tr>
<td></td>
<td><input type="submit" value="SIMPAN"></td>
</tr>
</table>
</form>
</body>
</html>