<!DOCTYPE html>
<html>
<head>
<title>Tambah Data SEMESTER</title>
</head>
<body>
<h2>Tambah Data SEMESTER</h2>
<br/>
<a href="index.php">KEMBALI</a>
<br/>
<form method="post" action="tambah_aksi.php">
<table>
<tr>
<td>Kode</td>
<td><input type="number" name="kd_semester"></td>
</tr>
<tr>
<td>Nama</td>
<td><input type="text" name="nama"></td>
</tr>
<tr>
<td></td>
<td><input type="submit" value="SIMPAN"></td>
</tr>
</table>
</form>
</body>
</html>