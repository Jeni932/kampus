<!DOCTYPE html>
<html>
<head>
<title>Tambah Data Dosen</title>
</head>
<body>
<h2>Tambah Data Dosen</h2>
<br/>
<a href="index.php">KEMBALI</a>
<br/>
<form method="post" action="tambah_aksi.php">
<table>
<tr>
<td>Kode</td>
<td><input type="number" name="kode_dosen"></td>
</tr>
<tr>
<td>Nama Dosen</td>
<td><input type="text" name="nama_dosen"></td>
</tr>
<tr>
<td>Alamat</td>
<td><input type="text" name="alamat"></td>
</tr>
<tr>
<td></td>
<td><input type="submit" value="SIMPAN"></td>
</tr>
</table>
</form>
</body>
</html>